"""
SCALE-Sim Configuration Generator for DNN Fault Simulation

This module generates SCALE-Sim configuration files and topology files from PyTorch layers.
It extracts layer parameters and converts them to SCALE-Sim format for cycle-accurate simulation.
"""

import os
import torch.nn as nn
from typing import Dict, Tuple


class ScaleSimConfigGenerator:
    """
    Generates SCALE-Sim configuration and topology files from PyTorch model layers.

    This class extracts layer parameters from PyTorch Conv2d layers and generates
    the necessary SCALE-Sim input files for simulation.
    """

    def __init__(self, output_dir: str = './scalesim_configs'):
        """
        Initialize the configuration generator.

        Args:
            output_dir: Directory to save generated config and topology files
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def extract_layer_info(self, layer: nn.Module, layer_name: str,
                          input_h: int, input_w: int) -> Dict:
        """
        Extract layer parameters from PyTorch Conv2d layer.

        Args:
            layer: PyTorch Conv2d layer
            layer_name: Name of the layer (e.g., 'conv1')
            input_h: Input height
            input_w: Input width

        Returns:
            Dictionary containing layer parameters:
            - layer_name: str
            - ifmap_h: int (input height)
            - ifmap_w: int (input width)
            - filter_h: int (kernel height)
            - filter_w: int (kernel width)
            - channels: int (input channels)
            - num_filters: int (output channels)
            - stride: int
            - padding: int
        """
        if not isinstance(layer, nn.Conv2d):
            raise ValueError(f"Layer {layer_name} must be nn.Conv2d, got {type(layer)}")

        layer_info = {
            'layer_name': layer_name,
            'ifmap_h': input_h,
            'ifmap_w': input_w,
            'filter_h': layer.kernel_size[0] if isinstance(layer.kernel_size, tuple) else layer.kernel_size,
            'filter_w': layer.kernel_size[1] if isinstance(layer.kernel_size, tuple) else layer.kernel_size,
            'channels': layer.in_channels,
            'num_filters': layer.out_channels,
            'stride': layer.stride[0] if isinstance(layer.stride, tuple) else layer.stride,
            'padding': layer.padding[0] if isinstance(layer.padding, tuple) else layer.padding,
        }

        return layer_info

    def generate_topology_csv(self, layer_info: Dict, output_file: str) -> str:
        """
        Generate SCALE-Sim topology CSV file.

        SCALE-Sim topology format:
        Layer name, IFMAP Height, IFMAP Width, Filter Height, Filter Width,
        Channels, Num Filter, Strides,

        Args:
            layer_info: Layer information dictionary
            output_file: Output filename (without path)

        Returns:
            Full path to generated topology file
        """
        topo_path = os.path.join(self.output_dir, output_file)

        with open(topo_path, 'w') as f:
            # Header
            f.write("Layer name, IFMAP Height, IFMAP Width, Filter Height, Filter Width, "
                   "Channels, Num Filter, Strides,\n")

            # Layer data
            f.write(f"{layer_info['layer_name']},")
            f.write(f"{layer_info['ifmap_h']}, {layer_info['ifmap_w']}, ")
            f.write(f"{layer_info['filter_h']}, {layer_info['filter_w']}, ")
            f.write(f"{layer_info['channels']}, {layer_info['num_filters']}, ")
            f.write(f"{layer_info['stride']},\n")

        return topo_path

    def generate_config_file(self, array_h: int, array_w: int, dataflow: str,
                            topology_file: str, output_file: str,
                            ifmap_sram_kb: int = 64,
                            filter_sram_kb: int = 64,
                            ofmap_sram_kb: int = 64) -> str:
        """
        Generate SCALE-Sim configuration file.

        Args:
            array_h: Systolic array height (number of rows)
            array_w: Systolic array width (number of columns)
            dataflow: Dataflow type ('os', 'ws', or 'is')
            topology_file: Path to topology CSV file
            output_file: Output config filename (without path)
            ifmap_sram_kb: IFMAP SRAM size in KB
            filter_sram_kb: Filter SRAM size in KB
            ofmap_sram_kb: OFMAP SRAM size in KB

        Returns:
            Full path to generated config file
        """
        if dataflow not in ['os', 'ws', 'is']:
            raise ValueError(f"Invalid dataflow '{dataflow}'. Must be 'os', 'ws', or 'is'")

        config_path = os.path.join(self.output_dir, output_file)

        with open(config_path, 'w') as f:
            f.write("[general]\n")
            f.write(f"run_name = fault_sim_{array_h}x{array_w}_{dataflow}\n\n")

            f.write("[architecture_presets]\n")
            f.write(f"ArrayHeight: {array_h}\n")
            f.write(f"ArrayWidth: {array_w}\n")
            f.write(f"IfmapSramSzkB: {ifmap_sram_kb}\n")
            f.write(f"FilterSramSzkB: {filter_sram_kb}\n")
            f.write(f"OfmapSramSzkB: {ofmap_sram_kb}\n")
            f.write("IfmapOffset: 0\n")
            f.write("FilterOffset: 10000000\n")
            f.write("OfmapOffset: 20000000\n")
            f.write("Bandwidth: 10\n")
            f.write(f"Dataflow: {dataflow}\n")
            f.write("MemoryBanks: 1\n")
            f.write("ReadRequestBuffer: 32\n")
            f.write("WriteRequestBuffer: 32\n\n")

            f.write("[layout]\n")
            f.write("IfmapCustomLayout: False\n")
            f.write("IfmapSRAMBankBandwidth: 10\n")
            f.write("IfmapSRAMBankNum: 10\n")
            f.write("IfmapSRAMBankPort: 2\n")
            f.write("FilterCustomLayout: False\n")
            f.write("FilterSRAMBankBandwidth: 10\n")
            f.write("FilterSRAMBankNum: 10\n")
            f.write("FilterSRAMBankPort: 2\n\n")

            f.write("[sparsity]\n")
            f.write("SparsitySupport: false\n")
            f.write("SparseRep: ellpack_block\n")
            f.write("OptimizedMapping: false\n")
            f.write("BlockSize: 8\n")
            f.write("RandomNumberGeneratorSeed: 40\n\n")

            f.write("[run_presets]\n")
            f.write("InterfaceBandwidth: CALC\n")
            f.write("UseRamulatorTrace: False\n\n")

            # Note: topology file will be set programmatically, not in config

        return config_path

    def generate_layout_csv(self, layer_info: Dict, output_file: str) -> str:
        """
        Generate simple layout CSV file (default layout).

        For now, we use default layout without custom banking.

        Args:
            layer_info: Layer information dictionary
            output_file: Output filename (without path)

        Returns:
            Full path to generated layout file
        """
        layout_path = os.path.join(self.output_dir, output_file)

        # For default layout, create an empty CSV with proper header
        # SCALE-Sim will use default layout if no custom layout is specified
        with open(layout_path, 'w') as f:
            f.write("# Default layout - no custom banking\n")

        return layout_path


if __name__ == '__main__':
    # Example usage
    import torch

    # Create a sample conv layer (matching GTSRB conv1)
    conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, padding=1)

    # Initialize generator
    generator = ScaleSimConfigGenerator(output_dir='./test_scalesim_configs')

    # Extract layer info
    layer_info = generator.extract_layer_info(conv1, 'conv1', input_h=32, input_w=32)
    print("Layer Info:", layer_info)

    # Generate topology file
    topo_file = generator.generate_topology_csv(layer_info, 'conv1_topology.csv')
    print(f"Generated topology: {topo_file}")

    # Generate config file for 8x8 array with OS dataflow
    config_file = generator.generate_config_file(
        array_h=8, array_w=8, dataflow='os',
        topology_file=topo_file,
        output_file='conv1_8x8_os.cfg'
    )
    print(f"Generated config: {config_file}")
