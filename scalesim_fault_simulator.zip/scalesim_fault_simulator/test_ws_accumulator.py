"""
Test Script: WS Dataflow with Accumulator Fault

This reproduces the user's bug report:
- Dataflow: WS
- Array: 8x8
- Layer: conv1
- Fault: PE(1,1), accumulator_register, cycle 10, duration 1
- Expected: Fault coverage > 0% (NOT 0%!)
"""

import sys
import os

# Add paths
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'gtsrb_project'))

from scalesim_operand_matrix import OperandMatrixGenerator
from scalesim_dataflow_ws import SystolicComputeWS
from scalesim_fault_injector import ScaleSimFaultInjector, FaultModel


def test_ws_accumulator_fault():
    """Test WS dataflow with accumulator fault at cycle 10."""

    print("="*80)
    print("TEST: WS Dataflow with Accumulator Fault")
    print("="*80)
    print("\nReproducing user's bug report:")
    print("  Dataflow: WS (Weight Stationary)")
    print("  Array: 8×8")
    print("  Layer: conv1 (3→32, kernel=3×3, padding=1)")
    print("  Fault: PE(1,1), accumulator_register")
    print("  Timing: cycle 10, duration 1")
    print("  Old result: ❌ Fault coverage = 0%")
    print("  Expected: ✅ Fault coverage > 0%")
    print()

    # Step 1: Generate operand matrices for conv1
    print("[1/5] Generating operand matrices for conv1...")

    gen = OperandMatrixGenerator()
    gen.set_layer_params(
        ifmap_h=32, ifmap_w=32,
        filter_h=3, filter_w=3,
        num_channels=3, num_filters=32,
        stride=1, padding=1
    )

    ifmap_mat, filter_mat, ofmap_mat = gen.create_all_matrices()

    operand_mats = {
        'ifmap_matrix': ifmap_mat,
        'filter_matrix': filter_mat,
        'ofmap_matrix': ofmap_mat,
        'dimensions': gen.get_layer_info()
    }

    print(f"  ✓ Operand matrices created")
    print(f"    IFMAP: {ifmap_mat.shape}")
    print(f"    Filter: {filter_mat.shape}")
    print(f"    OFMAP: {ofmap_mat.shape}")

    # Step 2: Generate WS demand matrices
    print("\n[2/5] Generating WS demand matrices...")

    ws_compute = SystolicComputeWS(arr_h=8, arr_w=8)
    demand_mats = ws_compute.generate_demand_matrices(operand_mats)

    print(f"  ✓ Demand matrices generated")
    print(f"    Total cycles: {demand_mats['total_cycles']}")
    print(f"    Cycles per tile: {demand_mats['cycles_per_tile']}")
    print(f"      - Weight load: {demand_mats['weight_load_cycles']}")
    print(f"      - Input stream: {demand_mats['input_stream_cycles']}")
    print(f"      - Output drain: {demand_mats['output_drain_cycles']}")

    # Analyze cycle 10
    print(f"\n  Analysis of cycle 10:")
    pe_11_idx = 1 * 8 + 1  # PE(1,1) = row 1, col 1

    ifmap_at_10 = demand_mats['ifmap_demand'][10, pe_11_idx]
    filter_at_10 = demand_mats['filter_demand'][10, pe_11_idx]

    print(f"    PE(1,1) at cycle 10:")
    print(f"      IFMAP access: {ifmap_at_10} {'(valid)' if ifmap_at_10 >= 0 else '(no access)'}")
    print(f"      Filter access: {filter_at_10} {'(valid)' if filter_at_10 >= 0 else '(no access)'}")

    if ifmap_at_10 >= 0 and filter_at_10 >= 0:
        print(f"      → Both signals active: ✅ Accumulator fault WILL propagate!")
    else:
        print(f"      → Not both active: ⚠️ Accumulator fault may NOT propagate")

    # Step 3: Inject fault
    print("\n[3/5] Injecting accumulator fault at PE(1,1), cycle 10...")

    fault = FaultModel(
        fault_type=FaultModel.BIT_FLIP,
        location={
            'pe_row': 1,
            'pe_col': 1,
            'component': 'accumulator_register'
        },
        timing={
            'start_cycle': 10,
            'duration': 1
        }
    )

    injector = ScaleSimFaultInjector([fault])
    faulty_markers = injector.inject_faults(demand_mats)

    print(f"  ✓ Fault injected")
    print(f"    Affected addresses: {len(faulty_markers['affected_addresses'])}")

    # Check if computation was marked faulty
    faulty_comp_at_10 = faulty_markers['faulty_computation'][10, pe_11_idx]
    print(f"    PE(1,1) computation faulty at cycle 10: {faulty_comp_at_10}")

    # Step 4: Trace propagation
    print("\n[4/5] Tracing fault propagation...")

    affected_outputs = injector.trace_fault_propagation(
        demand_mats, operand_mats, faulty_markers
    )

    print(f"  ✓ Fault propagation traced")
    print(f"    Affected outputs: {len(affected_outputs)}")

    # Step 5: Map to tensor indices
    print("\n[5/5] Mapping to tensor indices...")

    exact_positions = injector.create_output_mapping(operand_mats, affected_outputs)

    affected_channels = sorted(exact_positions.keys())
    print(f"  ✓ Output mapping created")
    print(f"    Affected channels: {len(affected_channels)}")
    if len(affected_channels) <= 20:
        print(f"      Channel IDs: {affected_channels}")

    # Compute statistics
    stats = injector.compute_statistics(affected_outputs, operand_mats)

    print("\n" + "="*80)
    print("RESULTS:")
    print("="*80)
    print(f"Total outputs: {stats['total_outputs']}")
    print(f"Affected outputs: {stats['affected_outputs']}")
    print(f"Fault coverage: {stats['fault_coverage']*100:.2f}%")
    print("="*80)

    # Verdict
    print("\nVERDICT:")
    if stats['fault_coverage'] > 0:
        print("✅ SUCCESS! Fault coverage > 0%")
        print("   Bug is FIXED! Accumulator fault at cycle 10 correctly propagates.")
        print("\nWhy it works now:")
        print("  - Old code: Marked faulty_ifmap if ifmap_demand >= 0")
        print("  - New code: Marks faulty_computation only if BOTH ifmap AND filter active")
        print("  - At cycle 10 in WS: Both signals are active during input streaming")
        print("  - Component-aware logic correctly identifies impact!")
        return True
    else:
        print("❌ FAILED! Fault coverage still 0%")
        print("   Need to debug further.")
        return False


if __name__ == '__main__':
    success = test_ws_accumulator_fault()
    sys.exit(0 if success else 1)
