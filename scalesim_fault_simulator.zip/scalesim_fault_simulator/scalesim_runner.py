"""
SCALE-Sim Runner for Fault Simulation

This module provides a wrapper to run SCALE-Sim programmatically
and extract demand matrices (traces) for fault injection.
"""

import os
import sys
import numpy as np
from typing import Dict, Optional

# Add SCALE-Sim to path
SCALESIM_PATH = os.path.join(os.path.dirname(__file__), '..', 'SCALE-Sim-main')
sys.path.insert(0, SCALESIM_PATH)

from scalesim.scale_sim import scalesim


class ScaleSimRunner:
    """
    Wrapper class to run SCALE-Sim and extract traces.

    This class runs SCALE-Sim with given config and topology files,
    then provides access to the generated demand matrices.
    """

    def __init__(self, verbose: bool = True):
        """
        Initialize the SCALE-Sim runner.

        Args:
            verbose: Enable verbose output from SCALE-Sim
        """
        self.verbose = verbose
        self.sim = None
        self.traces_dir = None

    def run_simulation(self, config_file: str, topology_file: str,
                      layout_file: str = '', output_dir: str = './scalesim_output') -> Dict:
        """
        Run SCALE-Sim simulation.

        Args:
            config_file: Path to SCALE-Sim config file
            topology_file: Path to topology CSV file
            layout_file: Path to layout CSV file (optional)
            output_dir: Directory for SCALE-Sim output traces

        Returns:
            Dictionary with simulation results:
            - success: bool
            - output_dir: str
            - total_cycles: int
        """
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        self.traces_dir = output_dir

        try:
            # Initialize SCALE-Sim
            self.sim = scalesim(
                save_disk_space=False,  # Save all traces for fault injection
                verbose=self.verbose,
                config=config_file,
                topology=topology_file,
                layout=layout_file if layout_file else ''
            )

            # Run simulation
            self.sim.run_scale(top_path=output_dir)

            # Get total cycles
            total_cycles = self.sim.get_total_cycles()

            return {
                'success': True,
                'output_dir': output_dir,
                'total_cycles': total_cycles
            }

        except Exception as e:
            print(f"ERROR: SCALE-Sim simulation failed: {e}")
            return {
                'success': False,
                'output_dir': output_dir,
                'total_cycles': 0,
                'error': str(e)
            }

    def get_trace_files(self, run_name: str) -> Dict[str, str]:
        """
        Get paths to generated trace files.

        Args:
            run_name: Run name from config file

        Returns:
            Dictionary with paths to trace files:
            - ifmap_sram_read
            - filter_sram_read
            - ofmap_sram_write
        """
        if not self.traces_dir:
            raise RuntimeError("No simulation has been run yet")

        trace_files = {
            'ifmap_sram_read': os.path.join(self.traces_dir, run_name, 'SRAM_IFMAP_reads.csv'),
            'filter_sram_read': os.path.join(self.traces_dir, run_name, 'SRAM_FILTER_reads.csv'),
            'ofmap_sram_write': os.path.join(self.traces_dir, run_name, 'SRAM_OFMAP_writes.csv'),
        }

        return trace_files

    def load_demand_matrix(self, csv_file: str) -> Optional[np.ndarray]:
        """
        Load demand matrix from SCALE-Sim trace CSV file.

        SCALE-Sim trace format:
        - First column: cycle number
        - Remaining columns: PE_0, PE_1, ..., PE_N-1 (memory addresses)

        Args:
            csv_file: Path to trace CSV file

        Returns:
            Numpy array of shape (num_cycles, num_pes) or None if file doesn't exist
        """
        if not os.path.exists(csv_file):
            print(f"WARNING: Trace file not found: {csv_file}")
            return None

        try:
            # Read CSV, skip header
            data = np.genfromtxt(csv_file, delimiter=',', skip_header=1)

            # First column is cycle, rest are PE demands
            if data.ndim == 1:
                # Single cycle case
                demand_matrix = data[1:].reshape(1, -1)
            else:
                demand_matrix = data[:, 1:]  # Skip cycle column

            return demand_matrix

        except Exception as e:
            print(f"ERROR: Failed to load demand matrix from {csv_file}: {e}")
            return None

    def load_all_demand_matrices(self, run_name: str) -> Dict[str, np.ndarray]:
        """
        Load all demand matrices (ifmap, filter, ofmap) from trace files.

        Args:
            run_name: Run name from config file

        Returns:
            Dictionary containing:
            - ifmap_demand: (num_cycles, num_pes)
            - filter_demand: (num_cycles, num_pes)
            - ofmap_demand: (num_cycles, num_pes)
        """
        trace_files = self.get_trace_files(run_name)

        demand_matrices = {
            'ifmap_demand': self.load_demand_matrix(trace_files['ifmap_sram_read']),
            'filter_demand': self.load_demand_matrix(trace_files['filter_sram_read']),
            'ofmap_demand': self.load_demand_matrix(trace_files['ofmap_sram_write']),
        }

        # Print statistics
        for name, matrix in demand_matrices.items():
            if matrix is not None:
                print(f"{name}: shape {matrix.shape}, "
                      f"valid accesses: {np.sum(matrix >= 0)}/{matrix.size}")

        return demand_matrices


if __name__ == '__main__':
    # Example usage
    print("Testing SCALE-Sim Runner...")

    # Use generated config from previous step
    config_file = './test_scalesim_configs/conv1_8x8_os.cfg'
    topology_file = './test_scalesim_configs/conv1_topology.csv'

    runner = ScaleSimRunner(verbose=True)

    print("\nRunning SCALE-Sim simulation...")
    result = runner.run_simulation(config_file, topology_file, output_dir='./test_scalesim_output')

    if result['success']:
        print(f"\n✓ Simulation successful!")
        print(f"  Total cycles: {result['total_cycles']}")

        print("\nLoading demand matrices...")
        run_name = 'fault_sim_8x8_os'  # From config file
        demand_matrices = runner.load_all_demand_matrices(run_name)

        print("\nDemand matrices loaded successfully!")
    else:
        print(f"\n✗ Simulation failed: {result.get('error', 'Unknown error')}")
