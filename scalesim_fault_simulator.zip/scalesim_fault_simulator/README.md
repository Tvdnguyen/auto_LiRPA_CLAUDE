# SCALE-Sim Based Fault Simulator

Component-aware systolic array fault simulator based on SCALE-Sim architecture.

## Features

- ✅ **SCALE-Sim Based**: Algorithms extracted from validated SCALE-Sim source code
- ✅ **Component-Aware**: Proper modeling of PE components (accumulator, MAC, registers)
- ✅ **3 Dataflows**: OS, WS, IS fully supported
- ✅ **Bug Fixed**: Accumulator fault coverage 0% → 12.50%
- ✅ **Interactive UI**: Easy-to-use interface for fault definition
- ✅ **Auto-LiRPA Integration**: Direct export to verification pipeline

## Quick Start

### Interactive Mode

```bash
python3 fault_simulator.py
```

Follow prompts to:
1. Configure array (e.g., 8×8)
2. Select dataflow (OS/WS/IS)
3. Choose layer (conv1, conv2, etc.)
4. Define faults (PE location, component, timing)
5. View results and export

### Example: Reproducing User's Bug

```bash
# Run simulator
python3 fault_simulator.py

# Inputs:
Array size: 8
Dataflow: 2 (WS)
Layer: 0 (conv1)
PE: 1,1
Component: 2 (accumulator_register)
Start cycle: 10
Duration: 1

# Output:
Fault coverage: 12.50%
Affected outputs: 4096/32768
Affected channels: [1, 9, 17, 25]
```

## Modules

| Module | Based On | Function |
|--------|----------|----------|
| `scalesim_operand_matrix.py` | operand_matrix.py:195-381 | Generate address matrices |
| `scalesim_dataflow_os.py` | systolic_compute_os.py | OS demand matrices |
| `scalesim_dataflow_ws.py` | systolic_compute_ws.py | WS demand matrices |
| `scalesim_dataflow_is.py` | systolic_compute_is.py | IS demand matrices |
| `scalesim_fault_injector.py` | Component PE model | Fault injection & propagation |
| `fault_simulator.py` | - | Interactive UI |

## Component-Aware Fault Modeling

### Supported Components

1. **MAC Unit**: Affects all computation
2. **Accumulator Register**: Only affects during MAC (both ifmap AND filter active)
3. **Input Register**: Only affects ifmap accesses
4. **Weight Register**: Only affects filter accesses
5. **Control Logic**: Affects all operations
6. **Entire PE**: Affects everything

### Key Fix

**Old Bug**:
```python
if pe_faults:
    if ifmap_demand >= 0:
        faulty_ifmap = True  # ❌ Wrong for accumulator!
```

**New Fix**:
```python
if component == 'accumulator_register':
    if ifmap_demand >= 0 and filter_demand >= 0:  # ✅ Both required!
        faulty_computation = True
```

## Test Results

### WS Accumulator Fault (cycle 10)

**Before**:
- Fault coverage: 0.00%
- Affected outputs: 0

**After**:
- Fault coverage: 12.50%
- Affected outputs: 4096
- Affected channels: [1, 9, 17, 25]

**Validation**: ✅ PASSED

## Integration with auto_LiRPA

```python
# Run simulator to get exact_positions
exact_positions = {
    1: {0: [cols], 1: [cols], ...},
    9: {...}, 17: {...}, 25: {...}
}

# Convert to elements list
fault_elements = []
for ch, rows in exact_positions.items():
    for row, cols in rows.items():
        for col in cols:
            fault_elements.append((ch, row, col))

# Use in main_interactive.py
perturbation_regions = [{
    'type': 'exact_elements',
    'elements': fault_elements
}]
```

## Documentation

- `SCALESIM_STANDALONE_IMPLEMENTATION.md` - Architecture and approach
- `SCALESIM_FAULT_SIMULATOR_FINAL.md` - Complete summary and validation
- `test_ws_accumulator.py` - Test script for bug validation

## Requirements

- Python 3.7+
- numpy
- TrafficSignNet model (for layer info)

## Files

```
scalesim_fault_simulator/
├── scalesim_operand_matrix.py    # Operand matrices
├── scalesim_dataflow_os.py       # OS dataflow
├── scalesim_dataflow_ws.py       # WS dataflow
├── scalesim_dataflow_is.py       # IS dataflow
├── scalesim_fault_injector.py    # Fault injection
├── fault_simulator.py            # Main interactive UI
├── test_ws_accumulator.py        # Validation test
├── __init__.py                   # Package init
└── README.md                     # This file
```

## License

Based on SCALE-Sim architecture (MIT License).

## Author

Claude (Implementation based on SCALE-Sim source code analysis)

## References

- SCALE-Sim: https://github.com/ARM-software/SCALE-Sim
- Paper: "SCALE-Sim: Systolic CNN AcceLerator Simulator"
